const scriptURL = 'https://script.google.com/macros/s/AKfycbxQwrL77Li0BQj5k9iIgyV3lgaIT2K3sHIrLhFRhs5ZpAvI11h7da6G_uGAUiJ1tzAglQ/exec';  // Replace with your Google Apps Script URL
const form = document.getElementById('contact-form');

form.addEventListener('submit', e => {
  e.preventDefault();

  fetch(scriptURL, { method: 'POST', body: new FormData(form) })
    .then(response => {
      alert("Submitted successfully!");
      form.reset();
    })
    .catch(error => {
      console.error('Error!', error.message);
      alert("Something went wrong. Please try again.");
    });
});
